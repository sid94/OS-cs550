#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/wait.h>

/*
int n = 0;

void func(void){
  int p = n;
  n++;
  printf("p=%d n = %d",p,n);
  _exit(0);
}

int main() {
    printf("Inside Main");
    int id_1, id_2, id_3;
    
    id_1 = fork();
    if(id_1 == -1)
    { perror("Error while doing fork");
       exit(1);
      }
    if(id_1 == 0)
    {
     func();
    }
    
    id_2 = fork();
    if(id_2 == 0) func();
    
    waitpid(id_1, NULL, 0);
    
    id_3 = fork();
    if(id_3 == 0) func();
    
    waitpid(id_2, NULL, 0);
    waitpid(id_3, NULL, 0);
    
    return 0;
    
}
*/

int main(int argc, char *argv[])
{
    printf("PID of example.c = %d\n", getpid());
    char *args[] = {"Hello", "C", "Programming", NULL};
    execv("./hello", args);
    printf("Back to example.c");
    return 0;
}